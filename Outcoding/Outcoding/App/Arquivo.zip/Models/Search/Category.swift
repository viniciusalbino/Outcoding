
import Foundation

struct Category: Mappable {
    let id: Int
    let name: String
}
