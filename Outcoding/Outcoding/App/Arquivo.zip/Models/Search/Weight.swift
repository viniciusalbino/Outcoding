
import Foundation

struct Weight: Mappable {
    let imperial: String?
    let metric: String?
}
